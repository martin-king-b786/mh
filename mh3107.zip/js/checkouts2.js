$(document).ready(function(){
    $('.button.comorgname').click(function(){
        $('.comorg').slideToggle();
    });
});